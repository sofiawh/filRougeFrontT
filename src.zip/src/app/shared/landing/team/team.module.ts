export interface TeamModel {
    image: string;
    name: string;
    position: string;
  }
  