const Teams = [
    {
      image: 'assets/images/users/avatar-2.jpg',
      name: 'Nancy Martino',
      position: 'Team Leader',
    },
    {
        image: 'assets/images/users/avatar-10.jpg',
        name: 'Henry Baird',
        position: 'Full Stack Developer',
    },
    {
        image: 'assets/images/users/avatar-3.jpg',
        name: 'Frank Hook',
        position: 'Project Manager',
    },
    {
        image: 'assets/images/users/avatar-8.jpg',
        name: 'Donald Palmer',
        position: 'UI/UX Designer',
    },
    {
        image: 'assets/images/users/avatar-5.jpg',
        name: 'Erica Kernan',
        position: 'Web Designer',
    },
    {
        image: 'assets/images/users/avatar-4.jpg',
        name: 'Alexis Clarke',
        position: 'Backend Developer',
    },
    {
        image: 'assets/images/users/avatar-6.jpg',
        name: 'Marie Ward',
        position: 'Full Stack Developer',
    },
    {
        image: 'assets/images/users/avatar-7.jpg',
        name: 'Jack Gough',
        position: 'React Js Developer',
    },
  ];
  
  
  export { Teams };
  