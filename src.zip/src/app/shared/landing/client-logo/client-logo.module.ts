export interface clientLogoModel {
    image: string;
  }
  