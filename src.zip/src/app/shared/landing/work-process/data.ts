const Process = [
    {
      icon: 'ri-quill-pen-line',
      title: 'Tell us what you need',
      content: 'The profession and the employer and your desire to make your mark.',
    },
    {
      icon: 'ri-user-follow-line',
      title: 'Get free quotes',
      content: 'The most important aspect of beauty was, therefore, an inherent part.',
    },
    {
      icon: 'ri-book-mark-line',
      title: 'Deliver high quality product',
      content: 'We quickly learn to fear and thus automatically avoid potentially.',
    },
  ];
  
  
  export { Process };
  