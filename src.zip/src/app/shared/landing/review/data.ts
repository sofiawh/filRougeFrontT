const ClientLogo = [
    {
      content: 'I am givng 5 stars. Theme is great and everyone one stuff everything in theme. Future request should not affect current state of theme.',
      title: 'gregoriusus',
      subTitle: '- Skote User'
    },
    {
      content: 'Awesome support. Had few issues while setting up because of my device, the support team helped me fix them up in a day.Everything looks clean and good. Highly recommended!',
      title: 'GeekyGreenOwl',
      subTitle: '- Skote User'
    },
    {
      content: `Amazing template, Redux store and components is nicely designed. It's a great start point for an admin based project. Clean Code and good documentation. Template is completely in React and absolutely no usage of jQuery`,
      title: 'sreeks456',
      subTitle: '- Veltrix User'
    },
  ];
  
  export { ClientLogo };
  