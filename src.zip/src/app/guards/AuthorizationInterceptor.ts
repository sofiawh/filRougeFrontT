import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { KeycloakService } from 'keycloak-angular';

@Injectable()
export class AuthorizationInterceptor implements HttpInterceptor {

    constructor(private keycloakService: KeycloakService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // Récupérer le jeton d'accès de Keycloak
        const accessToken = this.keycloakService.getKeycloakInstance().token;

        // Vérifier si le jeton d'accès existe
        if (accessToken) {
            // Ajouter le jeton d'accès à l'en-tête Authorization de la requête
            request = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${accessToken}`
                }
            });
        }

        // Passer la requête au prochain gestionnaire dans la chaîne
        return next.handle(request);
    }
}
