export interface productModel {
  image: string;
  name: string;
  cat: string;
  stock: string;
  price: string;
  order: string;
  rating: string;
  date: string;
  time: string;
  type?: any;
}
