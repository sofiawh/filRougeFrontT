export interface Annonce {
    id: number;
    titre: string;
    description: string;
    prix: number;
    ratings: number;
    categorie: string;
    image: string;
    revenue: number;
    ordersDonation: number;
    message: string;
    // Ajoutez d'autres propriétés au besoin
}
