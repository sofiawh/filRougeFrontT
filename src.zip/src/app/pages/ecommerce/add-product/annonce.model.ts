import {commercantModel} from "./commercant.model";

export interface annonceModel {
    id: number;
    titre: string;
    description: string;
    prix: string;
    categorie: string;
    commercant: commercantModel;//number


}
