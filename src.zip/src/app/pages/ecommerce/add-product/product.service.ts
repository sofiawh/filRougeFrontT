import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {annonceModel} from "./annonce.model";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl = 'http://localhost:8222/api/v1/commercants/annonce'
  constructor(private http: HttpClient) { }

  createProduct(file: File, annonce: annonceModel/*any*/) {
    // Créer un objet FormData pour envoyer le fichier et les données de l'annonce

      // const annonce2: annonceModel={
      //     id: 1,
      //     titre:'Annonce 1 ',
      //     description:'descprition 1',
      //     prix: '100',
      //     categorie: 'ffff',
      //     commercant: {id:'1abc'}
      //     //     {
      //     //     id:'1abc',
      //     //     nomCommerce:'vvvv',
      //     //     adresse:'adress aaa',
      //     //     description: 'descrip commerce'
      //     // }
      //
      // }
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    formData.append('titre', annonce.titre);
    formData.append('description', annonce.description);
    formData.append('prix', annonce.prix.toString()); // Assurez-vous de convertir le prix en chaîne si nécessaire
    // Ajoutez d'autres champs d'annonce si nécessaire
    formData.append('categorie', annonce.categorie);
    // @ts-ignore
    //formData.append('commercant', annonce2.commercantId);
      formData.append('commercant.id', annonce.commercant.id);
      // formData.append('commercant', annonce2.commercant.adresse);
      // formData.append('commercant', annonce2.commercant.description);

    //
    // Définir les en-têtes requis pour le téléchargement de fichiers
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');

    // Effectuer la requête POST vers l'API backend
    return this.http.post<annonceModel>(this.baseUrl, formData, { headers: headers });


    // const formData: FormData = new FormData();
    // formData.append('file', file, file.name);
    // formData.append('annonce', JSON.stringify(annonce));
    //
    //
    // // Définition des en-têtes de la requête
    // // const headers = new HttpHeaders({
    // //   'Content-Type': 'multipart/form-data'
    // // });
    //
    // // Envoi de la requête avec les en-têtes configurés
    // return this.http.post(this.baseUrl, formData/*, { headers }*/);
  }


    getProducts() {
        // Effectuer une requête GET pour récupérer la liste des produits depuis l'API backend
        return this.http.get<any[]>(this.baseUrl);
    }


    updateProductRating(id: number, rating: number) {
        // Effectuer une requête PUT pour mettre à jour le rating d'un produit spécifique
        const url = `${this.baseUrl}/${id}`;
        // Supposons que vous deviez envoyer le nouveau rating dans le corps de la requête
        const body = { rating: rating };
        return this.http.put(url, body);
    }

  // Met à jour le message d'un produit
  updateProductMessage(productId: number, message: string): Observable<any> {
    const url = `${this.baseUrl}/${productId}/message`;
    return this.http.put(url, { message });
  }

  // Supprime le message d'un produit
  deleteProductMessage(productId: number): Observable<any> {
    const url = `${this.baseUrl}/${productId}/message`;
    return this.http.delete(url);
  }

  // addProductComment(productId: any, newCommentObj: {
  //   user: { name: any; id: any; avatar: string };
  //   content: any;
  //   timestamp: Date
  // }) {
  //   // Appeler le service HTTP pour ajouter le commentaire au produit avec l'ID correspondant
  //   return this.http.post<any>(`/api/produits/${productId}/commentaires`, newCommentObj);
  // }
}
