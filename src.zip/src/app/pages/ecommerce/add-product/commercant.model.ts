export interface commercantModel {
    id: string;
    // nomCommerce: string;
    // description: string;
    // adresse: string;


}
