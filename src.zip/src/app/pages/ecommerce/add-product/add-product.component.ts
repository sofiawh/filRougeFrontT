import { Component, OnInit } from '@angular/core';

// Ck Editer
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {ProductService} from "./product.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

import {annonceModel} from "./annonce.model";
import {AuthService} from "../../../core/guards/AuthService";
import { KeycloakService } from 'keycloak-angular';
import {KeycloakProfile} from "keycloak-js";
import {commercantModel} from "./commercant.model";




@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})

/**
 * AddProduct Component
 */
export class AddProductComponent implements OnInit {

    // bread crumb items
    breadCrumbItems!: Array<{}>;
    public Editor = ClassicEditor;

    productForm!: FormGroup;
    submitted = false;
    public profile!:KeycloakProfile;


    constructor(private service: ProductService,private formBuilder: FormBuilder, private authService: AuthService,  public keycloakService:KeycloakService) {
    }

    async ngOnInit(): Promise<void> {
        /**
         * BreadCrumb
         */
        this.breadCrumbItems = [
            {label: 'Ecommerce'},
            {label: 'Create Product', active: true}
        ];

        this.productForm = this.formBuilder.group({
            id: [''],
            title: ['', [Validators.required]],
            price: ['', /*[Validators.required]*/],
            categorie: [''/*, [Validators.required]*/],
            image: ['', /*[Validators.required]*/],
            description: ['',/* [Validators.required]*/]
        });

        // Initialise l'ID de l'utilisateur en récupérant les informations de l'utilisateur connecté
        // this.keycloakService.loadUserProfile().then(profile => {
        //     if (profile && profile.id) { // Vérifie si profile et profile.id ne sont pas undefined
        //         const idKeycloak = parseInt(profile.id, 10); // Convertit la chaîne en nombre
        //         if (!isNaN(idKeycloak)) { // Vérifie si la conversion est réussie
        //             // Appelle la méthode du service pour obtenir l'utilisateur par son ID Keycloak
        //             this.userService.getUserByIdKeycloak(idKeycloak).subscribe(
        //                 (user: userModel) => {
        //                     // Met à jour le formulaire avec l'ID de l'utilisateur
        //                     this.productForm.patchValue({
        //                         userId: user.id
        //                     });
        //                 },
        //                 error => {
        //                     console.error('Erreur lors de la récupération de l\'utilisateur par ID Keycloak', error);
        //                 }
        //             );
        //         } else {
        //             console.error('ID Keycloak non valide');
        //         }
        //     } else {
        //         console.error('Profil utilisateur ou ID Keycloak non défini');
        //     }
        // }).catch(error => {
        //     console.error('Erreur lors de la récupération du profil utilisateur', error);
        // });

        if (await this.keycloakService.isLoggedIn()) {
            this.keycloakService.loadUserProfile().then(profile => {
                this.profile = profile;
                console.log("profile.id*** "+profile.id);
            })
        }
    }

    /**
     * Multiple Default Select2
     */
    selectValue = ['Choice 1', 'Choice 2', 'Choice 3'];


    get form() {
        return this.productForm.controls;
    }

    onSubmit() {
        const fileInput = document.getElementById('product-image-input') as HTMLInputElement;
        // @ts-ignore
        const file = fileInput.files[0];

        if (this.productForm.valid) {
            const id = 1;
            const titre = this.productForm.get('title')?.value;
            const description = this.productForm.get('description')?.value;
            const prix = this.productForm.get('price')?.value;
            const categorie = this.productForm.get('categorie')?.value;
            // const date = this.customerForm.get('date')?.value;
            // const status = this.customerForm.get('status')?.value;
            // const statusClass = "success";


            const commercant: commercantModel = {
                id:this.profile.id ? this.profile.id:'1abc',
                // nomCommerce: 'Nouveau produit',
                // description: 'Une description de mon produit',
                // adresse: '1000abc'
            }



            // @ts-ignore
            const annonce: annonceModel = {
                id,
                titre,
                description,
                prix,
                categorie,
                commercant:commercant
                // date,
                // status,
                // statusClass
            };
            // @ts-ignore
            // @ts-ignore

                //"ratings":
            // const annonce2: annonceModel = {
            //     id,
            //     "titre": "Nouveau produit",
            //     "description": "Une description de mon produit",
            //     "prix": "1000",
            //     //"ratings": 0,
            //     "categorie": "Alimentation",
            //
            //     //"revenue": 0,
            //    // "ordersDonation": 0,
            //   //  "message": "Nouveau produit disponible !",
            //     "commercant": {
            //     "id": "1",
            //       //  "idKeyCloak": 123456,
            //        // "nomCommerce": "Nom de votre commerce",
            //         //"description": "Description de votre commerce",
            //        // "adresse": "Adresse de votre commerce"
            // }
           // }
            console.log(" /// cat: "+annonce.categorie+" ** description * "+annonce.description);
            this.service.createProduct(file, annonce).subscribe(
                response => {
                    console.log('Annonce created successfully', response);
                    // Handle success
                },
                error => {
                    console.error('Error creating annonce', error);
                    // Handle error
                }
            );
        }

        this.submitted = true;
    }


}

