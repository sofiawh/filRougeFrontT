import {Component, ElementRef, QueryList, ViewChild, ViewChildren} from '@angular/core';
import {DecimalPipe} from '@angular/common';
import {Observable} from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';

// Sweet Alert
import Swal from 'sweetalert2';

import {customerModel} from './customers.model';
//import { Customers } from './data';
import { AdvancedService } from './customers.service';
import { NgbdAdvancedSortableHeader, SortEvent } from './customers-sortable.directive';
import {userModel} from "./users.model";
import {KeycloakService} from "keycloak-angular";

@Component({
    selector: 'app-customers',
    templateUrl: './customers.component.html',
    styleUrls: ['./customers.component.scss'],
    providers: [AdvancedService, DecimalPipe]
})

/**
 * Customers Component
 */
export class CustomersComponent {
//@ViewChildren('content') content: any;
    @ViewChild('content') content!: ElementRef; // Déclarez la propriété content avec @ViewChild

    // bread crumb items
    breadCrumbItems!: Array<{}>;
    submitted = false;
    customerForm!: FormGroup;
    CustomersData!: customerModel[];
    masterSelected!:boolean;
    checkedList:any;
    editMode = false; // Ajout de la variable editMode
    // Table data
    invoiceList$!: Observable<customerModel[]>;
    total$: Observable<number>;
    @ViewChildren(NgbdAdvancedSortableHeader) headers!: QueryList<NgbdAdvancedSortableHeader>;
    private idKeycloak!: number;


    constructor(private modalService: NgbModal,public service: AdvancedService, private formBuilder: FormBuilder, private keycloakService: KeycloakService) {
        this.invoiceList$ = service.countries$;
        this.total$ = service.total$;
    }

    ngOnInit(): void {
        /**
         * BreadCrumb
         */
        this.breadCrumbItems = [
            { label: 'Ecommerce' },
            { label: 'Customers', active: true }
        ];

        /**
         * Form Validation
         */
        this.customerForm = this.formBuilder.group({
            id:[''],
            name: ['', [Validators.required]],
            email: ['', [Validators.required]],
            phone: ['', [Validators.required]],
            status: ['', [Validators.required]]
        });

        /**
         * fetches data
         */
        this._fetchData();
    }

    /**
     * User grid data fetches
     */
    // private _fetchData() {
    //     this.CustomersData = Customers;
    // }
    private _fetchData() {
        // Utilisez la méthode getClients() du service AdvancedService pour récupérer les données des clients
        this.service.getClients().subscribe(
            (clients) => {
                this.CustomersData = clients;
            },
            (error) => {
                console.error('Erreur lors de la récupération des données des clients :', error);
            }
        );
    }

    /**
     * Sort table data
     * @param param0 sort the column
     *
     */
    onSort({column, direction}: SortEvent) {
        // resetting other headers
        this.headers.forEach(header => {
            if (header.sortable !== column) {
                header.direction = '';
            }
        });

        this.service.sortColumn = column;
        this.service.sortDirection = direction;
    }

    /**
     * Confirmation mail model
     */
    // confirm() {
    //     Swal.fire({
    //         title: 'Are you sure ?',
    //         text: 'Are you sure you want to remove this record ?',
    //         icon: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#f46a6a',
    //         confirmButtonText: 'Yes, delete it!',
    //         cancelButtonText: 'Close'
    //     }).then(result => {
    //         if (result.value) {
    //             Swal.fire('Deleted!', 'Mail has been deleted.', 'success');
    //         }
    //     });
    // }

    // ch
    confirm(id: number) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: 'Êtes-vous sûr de vouloir supprimer cet utilisateur ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f46a6a',
            confirmButtonText: 'Oui, supprimer !',
            cancelButtonText: 'Fermer'
        }).then(result => {
            if (result.value) {
                // Récupérer l'identifiant de l'utilisateur à supprimer
                const userIdToDelete = id /* Logique pour récupérer l'identifiant de l'utilisateur à supprimer */;

                // Appeler la méthode deleteUser() du service avec l'identifiant de l'utilisateur
                this.service.deleteUser(userIdToDelete).subscribe(
                    () => {
                        // Gérer la réponse de la requête si nécessaire
                        Swal.fire('Supprimé !', 'L\'utilisateur a été supprimé.', 'success');
                    },
                    (error) => {
                        // Gérer les erreurs de la requête si nécessaire
                        console.error('Erreur lors de la suppression de l\'utilisateur :', error);
                    }
                );
            }
        });
    }


    /**
     * Open modal
     * @param content modal content
     */
    //Ch
    //
    // editUser(userId: number) {
    //     console.log('ID de l\'utilisateur :', userId);
    //     this.service.getUserById(userId).subscribe(
    //         (user) => {
    //             // Vérifiez que les informations de l'utilisateur sont correctement récupérées
    //             console.log('Informations de l\'utilisateur récupérées avec succès :', user);
    //
    //             this.customerForm.patchValue({
    //                 name: user.nom,
    //                 email: user.email,
    //                 // phone: user.phone,
    //                 // date: user.date,
    //                 // status: user.status
    //             });
    //             // Ouvrir le formulaire de modification dans la modal après avoir pré-rempli les données
    //            this.openModal(this.content);
    //         },
    //         (error) => {
    //             console.error('Erreur lors de la récupération des informations de l\'utilisateur :', error);
    //         }
    //     );
    // }

    saveEditedUser(/*userId: number*/) {
        if (this.customerForm.valid && this.editMode) {
            const editedUser: userModel = {
                id: this.customerForm.get('id')?.value,
                nom: this.customerForm.get('name')?.value,
                prenom: this.customerForm.get('name')?.value,
                email: this.customerForm.get('email')?.value,
                idKeyCloak: this.idKeycloak || 0, // Utilisez une valeur par défaut si idKeyCloak est undefined
                motDePasse: '' // Vous pouvez également ajouter une valeur par défaut pour motDePasse si nécessaire
                // phone: this.customerForm.get('phone')?.value,
                // date: this.customerForm.get('date')?.value,
                // status: this.customerForm.get('status')?.value
            };
            console.log("*****editedUser this.customerForm.get('id')*****"+this.customerForm.get('id'));

            this.service.updateUser(editedUser.id, editedUser).subscribe(
                () => {
                    Swal.fire('Modifié !', 'Les informations de l\'utilisateur ont été mises à jour.', 'success');
                    this.modalService.dismissAll();
                },
                (error) => {
                    console.error('Erreur lors de la mise à jour des informations de l\'utilisateur :', error);
                }
            );
        }

        this.submitted = true;
    }
    editUser(userId: number) {
        console.log('ID de l\'utilisateur :', userId);
        this.editMode = true; // Définir editMode sur true pour activer le mode d'édition

        let content: any; // Définissez une variable locale pour contenir l'élément de contenu de la modal

        this.service.getUserById(userId).subscribe(
            (user) => {
                // Vérifiez que les informations de l'utilisateur sont correctement récupérées
                console.log('Informations de l\'utilisateur récupérées avec succès :', user);

                // Mettez à jour les champs du formulaire avec les informations de l'utilisateur récupérées
                this.customerForm.patchValue({
                    id: user.id,
                    name: user.nom,
                    email: user.email,
                    // Mettez à jour d'autres champs du formulaire si nécessaire
                });

                // Obtenez l'élément de contenu de la modal à partir de la vue enfant
               // content = this.content.nativeElement;

                // Ouvrir la modal avec le contenu pré-rempli
                this.openModal(/*content*/);
            },
            (error) => {
                console.error('Erreur lors de la récupération des informations de l\'utilisateur :', error);
            }
        );
    }



    openModal(/*content: any*/) {


            if (this.content) {
                this.submitted = false;
                // Ouvrir la modal en utilisant le contenu spécifié
                // Vous pouvez utiliser la bibliothèque de modals de votre choix ici
                // Par exemple, si vous utilisez NgbModal de ng-bootstrap :
                console.log("********content***"+this.content.toString());
                this.modalService.open(this.content);
                // Assurez-vous d'importer NgbModal et de l'injecter dans le constructeur
            } else {
                console.error("Le contenu de la modal n'est pas défini.");
            }
        }

        // // Réinitialiser la soumission du formulaire lorsque la modal est ouverte
        // this.submitted = false;
        // // Ouvrir la modal avec le contenu passé en paramètre
        // this.modalService.open(content, { size: 'lg', centered: false });
        // //this.editUser(content);
    //}

    /**
     * Form data get
     */
    get form() {
        return this.customerForm.controls;
    }

    /**
     * Save user
     */
    // saveUser() {
    //     if (this.customerForm.valid) {
    //         const name = this.customerForm.get('name')?.value;
    //         const email = this.customerForm.get('email')?.value;
    //         const phone = this.customerForm.get('phone')?.value;
    //         const date = this.customerForm.get('date')?.value;
    //         const status = this.customerForm.get('status')?.value;
    //         const statusClass = "success";
    //         this.CustomersData.push({
    //             name,
    //             email,
    //             phone,
    //             date,
    //             status,
    //             statusClass
    //         });
    //         this.modalService.dismissAll()
    //     }
    //     this.submitted = true
    // }


    saveUser() {


        if (this.customerForm.valid && !this.editMode) {
            const id = 1;
            const nom = this.customerForm.get('name')?.value;
            const prenom = this.customerForm.get('name')?.value;
            const email = this.customerForm.get('email')?.value;
            const phone = this.customerForm.get('phone')?.value;
            const date = this.customerForm.get('date')?.value;
            const status = this.customerForm.get('status')?.value;
            const statusClass = "success";


            // @ts-ignore
            this.keycloakService.loadUserProfile().then(profile => {
                if (profile && profile.id) {
                    this.idKeycloak = parseInt(profile.id, 10);
                }

                const newUser: userModel = {
                id,
                nom,
                prenom : nom,
                email,
                idKeyCloak: this.idKeycloak,
                    motDePasse: ''
                // phone,
                // date,
                // status,
                // statusClass
            };

            this.service.createUser(newUser).subscribe(
                (response) => {
                    // Gérer la réponse de la requête si nécessaire
                    console.log('New user created:', response);
                },
                (error) => {
                    // Gérer les erreurs de la requête si nécessaire
                    console.error('Error creating user:', error);
                }
            );

            this.modalService.dismissAll();
        });
            }
        this.submitted = true;
    }


    // The master checkbox will check/ uncheck all items
    checkUncheckAll() {
        for (var i = 0; i < this.CustomersData.length; i++) {
            this.CustomersData[i].isSelected = this.masterSelected;
        }
        this.getCheckedItemList();
    }

    // Get List of Checked Items
    getCheckedItemList(){
        this.checkedList = [];
        for (var i = 0; i < this.CustomersData.length; i++) {
            if(this.CustomersData[i].isSelected)
                this.checkedList.push(this.CustomersData[i]);
        }
        this.checkedList = JSON.stringify(this.checkedList);
    }

}
