export interface userModel {
    id: number;
  email: string;
  nom: string;
  prenom: string;

    idKeyCloak: number;
  //  name: string;

    motDePasse: string;
    // Ajoute d'autres propriétés si nécessaire

}
