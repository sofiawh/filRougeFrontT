/* eslint-disable @typescript-eslint/adjacent-overload-signatures */
import {Injectable, PipeTransform} from '@angular/core';

import {BehaviorSubject, Observable, of, Subject} from 'rxjs';

import {customerModel} from './customers.model';
import {userModel} from './users.model';
//import {Customers} from './data';
import {DecimalPipe} from '@angular/common';
import {debounceTime, delay, map, switchMap, tap} from 'rxjs/operators';
import {SortColumn, SortDirection} from './customers-sortable.directive';
import {HttpClient} from "@angular/common/http";


interface SearchResult {
  countries: customerModel[];
  total: number;
}

interface State {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn;
  sortDirection: SortDirection;
  startIndex: number;
  endIndex: number;
  totalRecords: number;
}

const compare = (v1: string | number, v2: string | number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

function sort(countries: customerModel[], column: SortColumn, direction: string): customerModel[] {
  if (direction === '' || column === '') {
    return countries;
  } else {
    return [...countries].sort((a, b) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

function matches(country: customerModel, term: string, pipe: PipeTransform) {
  return country.name.toLowerCase().includes(term.toLowerCase())
  || country.email.toLowerCase().includes(term.toLowerCase())
  || country.phone.toLowerCase().includes(term.toLowerCase())
  || country.date.toLowerCase().includes(term.toLowerCase())
  || country.status.toLowerCase().includes(term.toLowerCase());
}

@Injectable({providedIn: 'root'})
export class AdvancedService {
  private baseUrl = 'http://localhost:8222/api/v1/users'

  private _loading$ = new BehaviorSubject<boolean>(true);
  private _search$ = new Subject<void>();
  private _countries$ = new BehaviorSubject<customerModel[]>([]);
  private _total$ = new BehaviorSubject<number>(0);



  private _state: State = {
    page: 1,
    pageSize: 8,
    searchTerm: '',
    sortColumn: '',
    sortDirection: '',
    startIndex: 0,
    endIndex: 9,
    totalRecords: 0
  };

  constructor(private pipe: DecimalPipe, private http: HttpClient) {
    this._search$.pipe(
      tap(() => this._loading$.next(true)),
      debounceTime(200),
      switchMap(() => this._search()),
      delay(200),
      tap(() => this._loading$.next(false))
    ).subscribe(result => {
      this._countries$.next(result.countries);
      this._total$.next(result.total);
    });

    this._search$.next();
  }

  get countries$() { return this._countries$.asObservable(); }
  get total$() { return this._total$.asObservable(); }
  get loading$() { return this._loading$.asObservable(); }
  get page() { return this._state.page; }
  get pageSize() { return this._state.pageSize; }
  get searchTerm() { return this._state.searchTerm; }
  get startIndex() { return this._state.startIndex; }
  get endIndex() { return this._state.endIndex; }
  get totalRecords() { return this._state.totalRecords; }

  set page(page: number) { this._set({page}); }
  set pageSize(pageSize: number) { this._set({pageSize}); }
  set searchTerm(searchTerm: string) { this._set({searchTerm}); }
  set sortColumn(sortColumn: SortColumn) { this._set({sortColumn}); }
  set sortDirection(sortDirection: SortDirection) { this._set({sortDirection}); }
  set startIndex(startIndex: number) { this._set({ startIndex }); }
  set endIndex(endIndex: number) { this._set({ endIndex }); }
  set totalRecords(totalRecords: number) { this._set({ totalRecords }); }

  private _set(patch: Partial<State>) {
    Object.assign(this._state, patch);
    this._search$.next();
  }

  private _search(): Observable<SearchResult> {
    const {sortColumn, sortDirection, pageSize, page, searchTerm} = this._state;
//ch
    return this.getClients().pipe(
        map(clients => {
          clients = sort(clients, sortColumn, sortDirection);
          const filteredClients = clients.filter(client => matches(client, searchTerm, this.pipe));
          const total = filteredClients.length;
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize < total ? startIndex + pageSize : total;

          this._state.totalRecords = total;
          this._state.startIndex = startIndex + 1;
          this._state.endIndex = endIndex;

          return { countries: filteredClients.slice(startIndex, endIndex), total };
        })
    );

    // // 1. sort
    // let countries = sort(Customers, sortColumn, sortDirection);
    //
    // // 2. filter
    // countries = countries.filter(country => matches(country, searchTerm, this.pipe));
    // const total = countries.length;
    //
    // // 3. paginate
    // this.totalRecords = countries.length;
    // this._state.startIndex = (page - 1) * this.pageSize + 1;
    // this._state.endIndex = (page - 1) * this.pageSize + this.pageSize;
    // if (this.endIndex > this.totalRecords) {
    //     this.endIndex = this.totalRecords;
    // }
    // countries = countries.slice(this._state.startIndex - 1, this._state.endIndex);
    // return of({countries, total});
  }


  // /////ajouter par S
  // private baseUrl = '/api/v1/users';
  //
  //
  //
  // createUser(user: User): Observable<User> {
  //   return this.http.post<User>(this.baseUrl, user);
  // }
  //
  // getUserById(id: number): Observable<User> {
  //   return this.http.get<User>(`${this.baseUrl}/${id}`);
  // }
  //
  // getAllUsers(): Observable<User[]> {
  //   return this.http.get<User[]>(this.baseUrl);
  // }
  //
  // updateUser(id: number, user: User): Observable<User> {
  //   return this.http.put<User>(`${this.baseUrl}/${id}`, user);
  // }
  //
  // deleteUser(id: number): Observable<void> {
  //   return this.http.delete<void>(`${this.baseUrl}/${id}`);
  // }



    // Méthode pour récupérer les données des clients depuis le backend
  getClients(): Observable<customerModel[]> {
    return this.http.get<userModel[]>(this.baseUrl).pipe(
        map(users => {
          return users.map(user => ({
            id: user.id,
            name: `${user.prenom} ${user.nom}`,
            email: user.email,
            phone: '', // Remplissez le téléphone selon vos besoins
            date: '', // Remplissez la date selon vos besoins
            status: '', // Remplissez le statut selon vos besoins
            statusClass: '' ,// Remplissez la classe de statut selon vos besoins
            isSelected: false // Assurez-vous que chaque élément possède cette propriété
          }));
        })
    );
  }

  createUser(user: userModel): Observable<userModel> {
    return this.http.post<userModel>(this.baseUrl, user);
  }
  deleteUser(userId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${userId}`);
  }
  getUserById(id: number): Observable<userModel> {
    return this.http.get<userModel>(`${this.baseUrl}/${id}`);
  }
  updateUser(id: number, user: userModel): Observable<userModel> {
    return this.http.put<userModel>(`${this.baseUrl}/${id}`, user);
  }

  // getUserById(userId: number): Observable<UserEntity> {
  //   return this.http.get<UserEntity>(`${this.baseUrl}/${userId}`);
  // }
  getUserByIdKeycloak(idKeycloak: number): Observable<userModel> {
    return this.http.get<userModel>(`${this.baseUrl}/keycloak/${idKeycloak}`);
  }
}
