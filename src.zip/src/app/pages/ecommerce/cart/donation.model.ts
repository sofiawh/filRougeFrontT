export interface donationModel {

    id: number;
    amount:number;
    userId: string;
    associationId: string;
    status: string;
    annonceId: number;
    date: any;
    Pmethod: string;
 }
