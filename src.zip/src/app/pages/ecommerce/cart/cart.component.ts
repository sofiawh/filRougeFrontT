import { Component, OnInit } from '@angular/core';

import { Cart } from './cart.model';
import { cartData } from './data';

// Sweet Alert
import Swal from 'sweetalert2';
import {ProductService} from "../add-product/product.service";
import {KeycloakService} from "keycloak-angular";
import {HttpClient, HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import {AuthService} from "../../../core/guards/AuthService";
import {catchError, map} from "rxjs/operators";
import {Observable, throwError } from 'rxjs';
import {OrdersService} from "../orders/orders.service";
import { donationModel } from './donation.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})

/**
 * Cart Component
 */
export class CartComponent implements OnInit {

  // bread crumb items
  breadCrumbItems!: Array<{}>;
  cartData!: Cart[];
///
    products: any[] = []; // Liste des produits
    stars: number[] = [1, 2, 3, 4, 5]; // Nombre d'étoiles pour le rating
    selectedAssociation: string = ''; // Association sélectionnée
    message: string = ''; // Message
    //associations: string[] = ['Association 1', 'Association 2', 'Association 3']; // Liste des associations
    ////
    associations: { id: number, nom: string , email: string, localisation: string}[] = [];

    //constructor() { }
    currentUser: any;
    newComment: any;
     orderCompleted: boolean = false ;

    constructor(private ordersService: OrdersService, private productService: ProductService, private keycloakService: KeycloakService , private http: HttpClient, private authService: AuthService) { }

  async ngOnInit(): Promise<void> {
    /**
    * BreadCrumb
    */
     this.breadCrumbItems = [
      { label: 'Ecommerce' },
      { label: 'Shopping Cart', active: true }
    ];

    /**
     * fetches the data
     */
     this._fetchData();


      // Charger les produits lors de l'initialisation
      this.loadProducts();

      this.getAssociations().subscribe((data: any) => {
          this.associations = data; // Supposons que data est une liste d'associations
      });

      // Assurez-vous que l'utilisateur est connecté avant de récupérer le currentUser
      if (await this.keycloakService.isLoggedIn()) {
          // Chargez le profil de l'utilisateur actuellement authentifié
          await this.keycloakService.loadUserProfile().then(profile => {
              // Stockez le profil de l'utilisateur dans la variable currentUser
              this.currentUser = profile;
              console.log('currentUser:', this.currentUser);
          }).catch(error => {
              console.error('Erreur lors de la récupération du profil utilisateur:', error);
          });
      }


  }
    // loadProducts() {
    //     this.productService.getProducts().subscribe((data: any) => {
    //         this.products = data;
    //         this.products.forEach(product => {
    //             // Générez l'URL de l'image en incluant les en-têtes
    //             // @ts-ignore
    //             product.image = this.getImageUrl(product.id, this.http.defaults.headers);
    //           //  product.image = this.getImageUrl(product.id);
    //         });
    //     });
    // }
    // getImageUrl(idAnnonce: number, headers?: HttpHeaders): string {
    //     // Créez l'URL de base pour l'image
    //     let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
    //
    //     // Si des en-têtes sont fournis, ajoutez l'en-tête d'autorisation Bearer
    //     if (headers) {
    //         imageUrl += `?access_token=${headers.get('Authorization')?.replace('Bearer ', '')}`;
    //     }
    //
    //     return imageUrl;
    // }

    // Définissez votre méthode getImageUrl pour générer l'URL avec les en-têtes appropriés
    // getImageUrl(idAnnonce: number, token: string): string {
    //     // Créez l'URL de base pour l'image
    //     let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
    //
    //     // Créez les en-têtes avec le jeton d'accès
    //     const headers = new HttpHeaders({
    //         'Authorization': `Bearer ${token}`
    //     });
    //
    //     // Générez l'URL de l'image en incluant les en-têtes
    //     imageUrl += `?access_token=${token}`;
    //
    //     return imageUrl;
    // }


    // getImageUrl(idAnnonce: number): string {
    //     return `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
    // }
    // @ts-ignore
//     getImageUrl(idAnnonce: number, token: string): Observable<string>  {
//         // Créez l'URL de base pour l'image
//         let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
// console.log("***je suis gs getImage***")
//         // Ajoutez le jeton d'accès aux en-têtes si un jeton est fourni
//         let headers = new HttpHeaders();
//         if (token) {
//
//             headers = headers.set('Authorization', `Bearer ${token}`);
//         }
//
//         // Faites la demande HTTP avec les en-têtes si un jeton est fourni
//         if (token) {
//             this.http.get(imageUrl, { headers }).pipe/*subscribe*/(
//
//
//                 map(() => {
//                     // Retournez simplement l'URL de l'image sans la traiter
//                     console.log('Image récupérée avec succès'+imageUrl);
//                     return imageUrl;
//                 }),
//                 catchError(error => {
//                     console.error('Erreur lors de la récupération de l\'image:', error);
//                     throw error;
//                 })
//             );
//
//
//
//         //         response => console.log('Image récupérée avec succès'),
//         //         error => console.error('Erreur lors de la récupération de l\'image:', error)
//         //     );
//         // } else {
//         //     // Si aucun jeton n'est fourni, faites la demande HTTP sans en-têtes
//         //     this.http.get(imageUrl).subscribe(
//         //         response => console.log('Image récupérée avec succès'),
//         //         error => console.error('Erreur lors de la récupération de l\'image:', error)
//         //     );
//         // }
//         //
//         // return imageUrl;
//     }}
    // getImageUrl(idAnnonce: number, token: string): string {
    //     // Créez l'URL de base pour l'image
    //     let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
    //     // Assurez-vous que les paramètres sont corrects
    //     console.log('ID de l\'annonce:', idAnnonce);
    //     console.log('Token d\'accès:', token);
    //     // Ajoutez le jeton d'accès aux en-têtes si un jeton est fourni
    //     let headers = new HttpHeaders();
    //     if (token) {
    //         headers = headers.set('Authorization', `Bearer ${token}`);
    //     }
    //
    //     // Faites la demande HTTP avec les en-têtes si un jeton est fourni
    //     this.http.get(imageUrl, { headers, responseType: 'blob' }).pipe(
    //         catchError(this.handleError) // Gérez les erreurs potentielles
    //     ).subscribe(
    //         (imageBlob: Blob) => {
    //             // Traitez l'image Blob comme vous le souhaitez, par exemple, affichez-la dans votre application
    //             const imageUrl2 = URL.createObjectURL(imageBlob);// Convertir les données blob en URL d'image
    //             console.log('Image récupérée avec succès:', imageUrl2);
    //             return imageUrl; // Retourner l'URL d'image
    //         },
    //         (error: HttpErrorResponse) => {
    //             console.error('Erreur lors de la récupération de l\'image:', error);
    //         }
    //     );
    //
    //     return '';//imageUrl;
    // }

    getImageUrl(idAnnonce: number, token: string): Observable<string> {
        let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
        let headers = new HttpHeaders();
        if (token) {
            headers = headers.set('Authorization', `Bearer ${token}`);
        }

        return this.http.get(imageUrl, { headers, responseType: 'arraybuffer' }).pipe(
            map((imageData: ArrayBuffer) => {
                const base64Image = this.arrayBufferToBase64(imageData);
                const imageUrl = `data:image/jpeg;base64,${base64Image}`;
                console.log('Image récupérée avec succès:', imageUrl);
                return imageUrl;
            }),
            catchError(this.handleError)
        );
    }

    arrayBufferToBase64(buffer: ArrayBuffer): string {
        let binary = '';
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    }

    // getImageUrl(idAnnonce: number, token: string): Observable<string> {
    //     let imageUrl = `http://localhost:8222/api/v1/commercants/annonce/imageAnnonce/${idAnnonce}`;
    //     let headers = new HttpHeaders();
    //     if (token) {
    //         headers = headers.set('Authorization', `Bearer ${token}`);
    //     }
    //
    //     return this.http.get(imageUrl, { headers, responseType: 'blob' }).pipe(
    //         map((imageBlob: Blob) => {
    //             const imageUrl2 = URL.createObjectURL(imageBlob);
    //             console.log('Image récupérée avec succès:', imageUrl2);
    //             return imageUrl2;
    //         }),
    //         catchError(this.handleError)
    //     );
    // }
    async loadProducts() {
        const accessToken = await this.authService.getAccessToken();
        this.productService.getProducts().subscribe((data: any) => {
            this.products = data;
            this.products.forEach(product => {
             //   product.image = product.image;
                console.log('loadProduct vURL de l\'image:', product.image);
                this.getImageUrl(product.id, accessToken).subscribe(
                    imageUrl => {
                        product.image = imageUrl;
                        console.log('URL de l\'image mise à jour:', product.image);
                    },
                    error => {
                        console.error('Erreur lors de la récupération de l\'image:', error);
                    }
                );
            });
        });
    }


    // async loadProducts() {
    //     // Récupérez le jeton d'accès à partir du service d'authentification
    //     const accessToken = await this.authService.getAccessToken();
    //     // Créez un objet HttpHeaders pour inclure le jeton d'accès
    //   //  const headers = new HttpHeaders().set('Authorization', accessToken);
    //     //this.productService.getProducts({ headers }).subscribe((data: any) => {
    //     // Appeler le service pour charger les produits
    //     this.productService.getProducts().subscribe((data: any) => {
    //         this.products = data;
    //         this.products.forEach(product => {
    //             console.log('loadProduct vURL de l\'image:', product.image);
    //
    //             // Vérifiez si l'URL de l'image est accessible
    //
    //             product.image = this.getImageUrl(product.id, accessToken);
    //             this.checkImageUrl(product.image);
    //             console.log('Données des produits:', this.products);
    //         });
    //     });
    // }
    // checkImageUrl(url: string) {
    //     // Effectuez une requête HTTP HEAD pour vérifier si l'URL de l'image est accessible
    //     this.http.head(url).subscribe(
    //         () => console.log('L\'URL de l\'image est valide'),
    //         error => console.error('Erreur lors de la vérification de l\'URL de l\'image:', error)
    //     );
    // }
    // // Gérez les erreurs HTTP
    private handleError(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            // Erreur côté client
            console.error('Une erreur s\'est produite :', error.error.message);
        } else {
            // Erreur côté serveur
            console.error(
                `Code d'erreur côté serveur : ${error.status}, ` +
                `message : ${error.error}`);
        }
        // Renvoie une erreur observable avec un message convivial
        return throwError('Erreur lors du chargement de l\'image. Veuillez réessayer.');
    }


    rateProduct(product: any, rating: number) {
        // Mettre à jour le rating du produit
        product.rating = rating;
        // Appeler le service pour mettre à jour le rating dans la base de données
        this.productService.updateProductRating(product.id, rating).subscribe((data: any) => {
            Swal.fire('Succès', 'Le produit a été évalué avec succès', 'success');
        });
    }

    donateNow(product: any) {
        // Logique pour effectuer un don pour le produit sélectionné
        // Peut inclure l'envoi de données à un service externe, etc.
        console.log('Donation for product:', product);
    }
  /**
   * Cart data fetch
   */
   private _fetchData() {
    this.cartData = cartData;
  }

  // Default
  counter : any = 0;
  increment(id:any) {
    this.counter = (document.getElementById('cart-'+id) as HTMLInputElement).value;
    this.counter++;
    (document.getElementById('cart-'+id) as HTMLInputElement).value = this.counter;

  }

  decrement(id:any) {
    this.counter = (document.getElementById('cart-'+id) as HTMLInputElement).value;
    this.counter--;
    (document.getElementById('cart-'+id) as HTMLInputElement).value = this.counter;
  }

  /**
   * Confirmation mail model
   */
   confirm() {
    Swal.fire({
      title: 'Are you sure ?',
      text: 'Are you sure you want to remove this product ?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#f46a6a',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Close'
    }).then(result => {
      if (result.value) {
        Swal.fire('Deleted!', 'Cart has been deleted.', 'success');
      }
    });
  }


  editComment(product: any) {
      this.productService.updateProductMessage(product.id, product.message).subscribe((data: any) => {
          Swal.fire('Succès', 'Le message a été modifié avec succès', 'success');
      });
  }

    deleteComment(product: any) {
        this.productService.deleteProductMessage(product.id).subscribe((data: any) => {
            Swal.fire('Succès', 'Le message a été supprimé avec succès', 'success');
        });
    }


    // addComment(product: any) {
    //     // Vérifier si un nouveau commentaire a été saisi
    //     if (this.newComment && this.newComment.trim() !== '') {
    //         // Créer un objet représentant le nouveau commentaire
    //         const newCommentObj = {
    //             content: this.newComment,
    //             user: {
    //                 id: this.currentUser.id, // Utiliser l'ID de l'utilisateur actuel
    //                 name: this.currentUser.name, // Utiliser le nom de l'utilisateur actuel
    //                 avatar: 'url_de_l_avatar_de_l_utilisateur' // Remplacer par l'URL de l'avatar de l'utilisateur
    //             },
    //             timestamp: new Date() // Utiliser la date actuelle comme horodatage
    //         };
    //
    //         // Ajouter le nouveau commentaire à la liste des commentaires du produit
    //         product.comments.push(newCommentObj);
    //
    //         // Appeler le service pour ajouter le commentaire à la base de données (s'il y a lieu)
    //         this.productService.addProductComment(product.id, newCommentObj).subscribe((data: any) => {
    //             // Afficher une notification de succès si nécessaire
    //             Swal.fire('Succès', 'Le commentaire a été ajouté avec succès', 'success');
    //         });
    //
    //         // Réinitialiser le champ de saisie du nouveau commentaire
    //         this.newComment = '';
    //     } else {
    //         // Afficher un message d'erreur si aucun commentaire n'a été saisi
    //         Swal.fire('Erreur', 'Veuillez saisir un commentaire valide', 'error');
    //     }
    // }
    private urlAss: string = `http://localhost:8222/api/v1/associations`;

    confirm2() {
        Swal.fire({
            title: 'Merci ! Votre Donation est terminée !',
            html: `
            <div class="mb-4">
                <lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#0ab39c,secondary:#405189" style="width:120px;height:120px"></lord-icon>
            </div>
            <h5>Merci ! Votre donation est terminée !</h5>
        
            
      `,
            icon: 'success',
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
        });
    }
    onSubmit(product: any) {
        const orderData = {
            id: 0,
            name: this.currentUser.id, //"03dd44e4-1d33-44ed-a244-de370960909b",
            association: this.selectedAssociation ,//"5c8181cc-9ed3-4e25-95eb-db55c5b166c2",
            product: product.id,
            date: 'aujourdhui',
            time: '00:00',
            amount: product.prix.toString(),
            pmethod: 'Visa Card',
            status: 'pending',
            isSelected:true,
            // productId: product.id,
            // associationId: this.selectedAssociation,
            // userId: "03dd44e4-1d33-44ed-a244-de370960909b",
            // amount: product.amount
            // Ajoutez d'autres informations nécessaires pour créer la command
        };

        this.ordersService.createOrder(orderData).subscribe(
            (response) => {
                this.confirm2();
                console.log('Com créée avec succès !', response);
                // Effectuez des actions supplémentaires si nécessaire, comme naviguer vers une autre page
            },
            (error) => {
                console.error('Une erreur s\'est produite lors de la création de la commande', error);
            }
        );
        this.orderCompleted = true;
        // this.orderService.createOrder(orderData).subscribe(
        //     (response) => {
        //         console.log('Commande créée avec succès :', response);
        //     },
        //     (error) => {
        //         console.error('Échec de la création de la commande :', error);
        //     }
        // );

    }
    getAssociations() {
        return this.http.get<any>(this.urlAss);
    }


}

// OrdersModel {
//     id: string;
//     name: string;
//     association: string;
//     product: string;
//     date: string;
//     time: string;
//     amount: string;
//     pmethod: string;
//     status: string;
//     isSelected?:any;
