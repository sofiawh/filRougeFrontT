/* eslint-disable @typescript-eslint/adjacent-overload-signatures */
import {Injectable, PipeTransform} from '@angular/core';

import {BehaviorSubject, Observable, of, Subject} from 'rxjs';

import {OrdersModel} from './orders.model';
import {Orders} from './data';
import {DecimalPipe} from '@angular/common';
import {debounceTime, delay, map, switchMap, tap} from 'rxjs/operators';
import {SortColumn, SortDirection} from './orders-sortable.directive';
import {HttpClient} from "@angular/common/http";
import {donationModel} from "../cart/donation.model";
import {customerModel} from "../customers/customers.model";
import {userModel} from "../customers/users.model";

interface SearchResult {
  countries: OrdersModel[];
  total: number;
}

interface State {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn;
  sortDirection: SortDirection;
  startIndex: number;
  endIndex: number;
  totalRecords: number;
}

const compare = (v1: string | number, v2: string | number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

function sort(countries: OrdersModel[], column: SortColumn, direction: string): OrdersModel[] {
  if (direction === '' || column === '') {
    return countries;
  } else {
    return [...countries].sort((a, b) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

function matches(country: OrdersModel, term: string, pipe: PipeTransform) {
  return country.id.toLowerCase().includes(term.toLowerCase())
  || country.name.toLowerCase().includes(term.toLowerCase())
  || country.product.toLowerCase().includes(term.toLowerCase())
  || country.date.toLowerCase().includes(term.toLowerCase())
  || country.amount.toLowerCase().includes(term.toLowerCase())
  || country.pmethod.toLowerCase().includes(term.toLowerCase())
  || country.status.toLowerCase().includes(term.toLowerCase());

}

@Injectable({providedIn: 'root'})
export class OrdersService {
  private _loading$ = new BehaviorSubject<boolean>(true);
  private _search$ = new Subject<void>();
  private _countries$ = new BehaviorSubject<OrdersModel[]>([]);
  private _total$ = new BehaviorSubject<number>(0);

  private _state: State = {
    page: 1,
    pageSize: 8,
    searchTerm: '',
    sortColumn: '',
    sortDirection: '',
    startIndex: 0,
    endIndex: 9,
    totalRecords: 0
  };
  private API_URL= 'http://localhost:8222/api/v1/donations';
  private baseUrl = this.API_URL;

  constructor(private pipe: DecimalPipe , private http: HttpClient) {
    this._search$.pipe(
      tap(() => this._loading$.next(true)),
      debounceTime(200),
      switchMap(() => this._search()),
      delay(200),
      tap(() => this._loading$.next(false))
    ).subscribe(result => {
      this._countries$.next(result.countries);
      this._total$.next(result.total);
    });

    this._search$.next();
  }

  get countries$() { return this._countries$.asObservable(); }
  get total$() { return this._total$.asObservable(); }
  get loading$() { return this._loading$.asObservable(); }
  get page() { return this._state.page; }
  get pageSize() { return this._state.pageSize; }
  get searchTerm() { return this._state.searchTerm; }
  get startIndex() { return this._state.startIndex; }
  get endIndex() { return this._state.endIndex; }
  get totalRecords() { return this._state.totalRecords; }

  set page(page: number) { this._set({page}); }
  set pageSize(pageSize: number) { this._set({pageSize}); }
  set searchTerm(searchTerm: string) { this._set({searchTerm}); }
  set sortColumn(sortColumn: SortColumn) { this._set({sortColumn}); }
  set sortDirection(sortDirection: SortDirection) { this._set({sortDirection}); }
  set startIndex(startIndex: number) { this._set({ startIndex }); }
  set endIndex(endIndex: number) { this._set({ endIndex }); }
  set totalRecords(totalRecords: number) { this._set({ totalRecords }); }

  private _set(patch: Partial<State>) {
    Object.assign(this._state, patch);
    this._search$.next();
  }

  private _search(): Observable<SearchResult> {
    const {sortColumn, sortDirection, pageSize, page, searchTerm} = this._state;

    return this.getOrders().pipe(
        map(orders => {
          orders = sort(orders, sortColumn, sortDirection);
          const filteredOrders = orders.filter(order => matches(order, searchTerm, this.pipe));
          const total = filteredOrders.length;
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize < total ? startIndex + pageSize : total;

          this._state.totalRecords = total;
          this._state.startIndex = startIndex + 1;
          this._state.endIndex = endIndex;

          return { countries: filteredOrders.slice(startIndex, endIndex), total };
        })
    );

    // // 1. sort
    // let countries = sort(Orders, sortColumn, sortDirection);
    //
    // // 2. filter
    // countries = countries.filter(country => matches(country, searchTerm, this.pipe));
    // const total = countries.length;
    //
    // // 3. paginate
    // this.totalRecords = countries.length;
    // this._state.startIndex = (page - 1) * this.pageSize + 1;
    // this._state.endIndex = (page - 1) * this.pageSize + this.pageSize;
    // if (this.endIndex > this.totalRecords) {
    //     this.endIndex = this.totalRecords;
    // }
    // countries = countries.slice(this._state.startIndex - 1, this._state.endIndex);
    // return of({countries, total});
  }
  createOrder(orderData: any): Observable<any> {
    const donation: donationModel ={
          id: 1,
          amount:parseFloat(orderData.amount),
          userId: orderData.name,
          associationId: orderData.association ,
          status: orderData.status,
          annonceId: orderData.product,
          date: new Date(),
          Pmethod: orderData.pmethod
    }
    console.log(JSON.stringify(donation));
    return this.http.post(this.API_URL, donation);
  }

  getOrders(): Observable<OrdersModel[]> {
    return this.http.get<donationModel[]>(this.baseUrl).pipe(
        map(donations => {
          return donations.map(donation => ({
            id: donation.id.toString(),
            name: donation.userId,
            association: donation.associationId,
            product: donation.annonceId.toString(), // Remplissez le téléphone selon vos besoins
            date: donation.date.toString(), // Remplissez la date selon vos besoins
            time: '',
            amount: donation.amount.toString() ,
            pmethod: donation.Pmethod,
            status: donation.status, // Remplissez le statut selon vos besoins
            isSelected: false // Assurez-vous que chaque élément possède cette propriété
          }));
        })
    );
  }




  /*
    createOrder(orderData: { productId: number; associationId: string,userId: string, amount: string }): Observable<OrdersModel>{

        // Vous pouvez utiliser les données reçues pour créer une nouvelle commande
        const newOrder: OrdersModel = {
          id: "1", // Vous devrez implémenter une fonction pour générer un identifiant unique
          product: orderData.productId.toString(),
          association: orderData.associationId,
          amount: orderData.amount,
          name: '',
          status: '',
          pmethod: '',
          date: '',
          time: '',
          isSelected: ''
         // annonce: orderData.annonceId,
          // Ajoutez d'autres propriétés de commande si nécessaire
        };

      return this.http.post<OrdersModel>(this.API_URL, newOrder).pipe(
          tap((newOrd: OrdersModel) => {
            // Si la requête réussit, vous pouvez effectuer des actions supplémentaires si nécessaire
            console.log('Nouvelle commande créée : ', newOrd);



        // Ensuite, vous pouvez ajouter cette nouvelle commande à la liste des commandes
        const currentOrders = this._countries$.getValue(); // Obtenez les commandes actuelles
        const updatedOrders = [...currentOrders, newOrder]; // Ajoutez la nouvelle commande
        this._countries$.next(updatedOrders); // Mettez à jour la liste des commandes

        // Vous pouvez également effectuer d'autres actions nécessaires ici, comme sauvegarder les données

    })
      );}*/
}
