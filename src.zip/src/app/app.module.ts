import {APP_INITIALIZER, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
// Auth
import {HttpClientModule, HttpClient, HTTP_INTERCEPTORS} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// Language
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';

import {initFirebaseBackend} from './authUtils';

import {AppRoutingModule} from './app-routing.module';
import {LayoutsModule} from "./layouts/layouts.module";
import {PagesModule} from "./pages/pages.module";
import {AppComponent} from './app.component';

import {FakeBackendInterceptor} from './core/helpers/fake-backend';
import {ErrorInterceptor} from './core/helpers/error.interceptor';
import {JwtInterceptor} from './core/helpers/jwt.interceptor';
import {environment} from '../environments/environment';
import {KeycloakAngularModule, KeycloakService} from "keycloak-angular";
import {AuthorizationInterceptor} from "./guards/AuthorizationInterceptor";
import { DecimalPipe } from '@angular/common';


export function createTranslateLoader(http: HttpClient): any {
    return new TranslateHttpLoader(
        http,
        'assets/i18n/',
        '.json'
    );
}

if (environment.defaultauth === 'firebase') {
    initFirebaseBackend(environment.firebaseConfig);
} else {
    FakeBackendInterceptor;
}

function initializeKeycloak(keycloak: KeycloakService) {
    return () =>
        keycloak.init({
            config: {
                url: 'http://localhost:8080',
                realm: 'food-realm',
                clientId: 'food-client'
            },
            initOptions: {
                onLoad: 'check-sso',
                silentCheckSsoRedirectUri:
                    window.location.origin + '/assets/silent-check-sso.html'
            }
        });
}
@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        TranslateModule.forRoot({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        BrowserAnimationsModule,
        HttpClientModule,
        BrowserModule,
        /*==============================*/
        AppRoutingModule,
        /*==============================*/
        LayoutsModule,
        PagesModule,
        KeycloakAngularModule
    ],
    providers: [
        // {
        //     provide: HTTP_INTERCEPTORS,
        //     useClass: JwtInterceptor, multi: true
        // },
        // {
        //     provide: HTTP_INTERCEPTORS,
        //     useClass: ErrorInterceptor,
        //     multi: true
        // },
        // {
        //     provide: HTTP_INTERCEPTORS,
        //     useClass: FakeBackendInterceptor,
        //     multi: true
        // },
        KeycloakService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthorizationInterceptor,
            multi: true
        },
        {
            provide: APP_INITIALIZER,
            useFactory: initializeKeycloak,
            multi: true,
            deps: [KeycloakService]
        },  DecimalPipe
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
